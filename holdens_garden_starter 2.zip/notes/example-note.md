---
title: "Welcome to Holden's Garden"
date: 2025-05-28
---

This is the first note in your digital garden.
Feel free to edit or add new notes via Netlify CMS.
